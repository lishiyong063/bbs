from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class bbs_user(models.Model):
	user = models.OneToOneField(User)
	photo = models.ImageField(upload_to = 'pic_folder/',default = 'pic_folder/None/no-img.jpg')
	def __unicode__(self):
		return self.user.username
		
class bbs(models.Model):
	titele = models.CharField(max_length=100)
	category = models.ForeignKey('category')
	content = models.TextField()
	view_count = models.IntegerField(default=0)
	comment_count = models.IntegerField(default = 0)
	author = models.ForeignKey('bbs_user')
	ranking = models.IntegerField(default = 1000)
	publish_date = models.DateTimeField(auto_now_add=True)
	
	def __unicode__(self):
		return self.titele

class category(models.Model):
	name = models.CharField(max_length=30)
	order = models.IntegerField(default = 0)
	
	def __unicode__(self):
		return self.name