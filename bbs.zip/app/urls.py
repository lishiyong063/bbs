from django.conf.urls import patterns, include, url
import views


urlpatterns = patterns('',
        url(r'^$',views.index,{'template':'index.html'}),
        #(r'^bbs_result/(?P<id>\d+)/$',views.index,{'template':'bbs_result.html'}),
        (r'^bbs_result/(?P<id>\d+)/$',views.bbs_result),
        (r'^add_news/$',views.index,{'template':'add_news.html'}),
        (r'^submit_bbs/$',views.submit_bbs),
        (r'^latest_article/$',views.latest_article),
        (r'^get_new_article/$',views.get_new_article),
        (r'^login/$',views.login),
        (r'^login_auth/$',views.login_auth),
        (r'^logout/$',views.logout),
	(r'^sub_comment/(\d+)/$',views.sub_comment),
	(r'^register/$',views.register),
        (r'^category/(\d+)/$',views.category_fen),
        (r'^sub_register/$',views.sub_register),
		(r'^chat/$',views.chat),
)
